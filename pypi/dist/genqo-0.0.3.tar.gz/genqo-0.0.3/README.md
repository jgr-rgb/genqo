# genqo
A hybrid gaussian/non-gaussian quantum optics state engine
